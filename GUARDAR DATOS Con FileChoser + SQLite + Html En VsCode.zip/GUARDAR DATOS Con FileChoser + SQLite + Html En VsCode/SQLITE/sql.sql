

CREATE TABLE store( id INT PRIMARY KEY, name TEXT, price REAL, img BLOB);


